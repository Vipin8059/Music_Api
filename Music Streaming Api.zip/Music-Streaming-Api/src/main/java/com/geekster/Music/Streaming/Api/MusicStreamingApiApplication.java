package com.geekster.Music.Streaming.Api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MusicStreamingApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(MusicStreamingApiApplication.class, args);
	}

}
